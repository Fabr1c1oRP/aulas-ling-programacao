#include <stdio.h>

int main() {
    int i, j, soma = 0, matriz[3][3];

    printf("Digite as 3 notas: \n"); // Laço for para a entrada dos dados na matriz.
    for(i = 0; i < 3; i++) {
        for(j = 0; j < 3; j++) {
        printf("Digite o elemento[%d][%d]: \n", i+1, j+1);
        scanf("%d", &matriz[i][j]);
        }
    }

    for(i = 0; i < 3; i++) { // Laço for para comparar cada valor da matriz com o anterior.
        for(j = 0; j < 3; j++) {
        if(i == j) { // Se I = J, significa que é um elemento da diagonal princiapal.
            soma += matriz[i][j]; // Incrementa a variável soma com cada valor da diagonal principal encontrado.
        }
        }
    }
    printf("Soma da diagonal principal: %d\n", soma);

    return 0;
}