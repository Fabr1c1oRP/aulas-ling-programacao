#include <stdio.h>

int main() {
    int numeros[5], i = 0;
    

    for(i = 0; i < 5; i++) { // Laço FOR para a leitura e armazenamento dos 5 valores no vetor.
        printf("Digite o numero %d: \n", i+1);
        scanf("%d", &numeros[i]);
    }

    printf("Numeros maiores que 10: \n"); 
    for(i = 0; i < 5; i++) { // Laço FOR para mostrar valores maiores que 10 do vetor.
    if(numeros[i] > 10) { // IF com condição que compara o número de cada índice para mostrar os maiores que 10.
        printf("Numero %d: %d\n", i+1, numeros[i]);
    }
    }

    return 0;
}