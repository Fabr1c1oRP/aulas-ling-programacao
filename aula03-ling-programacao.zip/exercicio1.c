#include <stdio.h>

int main() {
    int numeros[4], media = 0, i = 0;
    
    for(i = 0; i < 4; i++) { // Laço for para leitura dos números e armazenamento no vetor
    printf("Digite o numero %d: \n", i+1);
    scanf("%d", &numeros[i]);
    media += numeros[i]; // Incrementa a variável média ao somar cada um dos valores digitados
    }
    media /= i; // Divide a soma salva na variável média pelo número de números lidos no vetor, e salva em média.
    printf("Media: %d\n", media);

    return 0;
}