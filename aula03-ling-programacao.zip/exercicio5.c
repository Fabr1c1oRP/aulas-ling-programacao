#include <stdio.h>

int main() {
    int i, j, cont = 0, matriz[2][3];

    printf("Digite as 3 notas: \n"); // Laço for para a entrada dos dados na matriz.
    for(i = 0; i < 2; i++) {
        for(j = 0; j < 3; j++) {
        printf("Digite o elemento[%d][%d]: \n", i+1, j+1);
        scanf("%d", &matriz[i][j]);
        }
    }

    for(i = 0; i < 2; i++) { // Laço for para comparar cada valor da matriz com o valor 5.
        for(j = 0; j < 3; j++) {
        if(matriz[i][j] > 5) {
            cont++; // Se maior que 5, variável "cont" recebe +1.
        }
        }
    }
    printf("Quantidade de numeros maiores que cinco: %d\n", cont);

    return 0;
}