#include <stdio.h>

int main() {
    int i, j, matriz[2][2];

    printf("Digite as 3 notas: \n"); // Laço for para a entrada dos dados na matriz.
    for(i = 0; i < 2; i++) {
        for(j = 0; j < 2; j++) {
        printf("Digite o elemento[%d][%d]: \n", i+1, j+1);
        scanf("%d", &matriz[i][j]);
        }
    }

int maior = matriz[0][0]; // Assume o primeiro valor da matriz como maior.
    for(i = 0; i < 2; i++) { // Laço for para comparar cada valor da matriz com o anterior.
        for(j = 0; j < 2; j++) {
        if(matriz[i][j] > maior) {
            maior = matriz[i][j]; // Se maior que o anterior, variável "maior" recebe esse valor.
        }
        }
    }
    printf("Maior numero: %d\n", maior);

    return 0;
}