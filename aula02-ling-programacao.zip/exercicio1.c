#include <stdio.h>
#include <math.h>

int main () {
    int pontos, resposta, aux, vabs;
    
    do { //laço de repetição para validação de pontuação inicial positiva
    printf("Digite a pontuacao inicial do jogador (apenas positivos):\n");
    scanf("%d", &pontos);
    if(pontos < 0) {
      printf("Digite a pontuacao inicial do jogador (apenas positivos):\n");
      scanf("%d", &pontos);
    }
    } while (pontos < 0);

    aux = pontos; //salva pontuação inicial

    //pergunta o resultados dos eventos e atualiza pontuação
    printf("Evento 1: O jogador ganhou uma fase? 1: Sim, 0: Nao.\n");
    scanf("%d", &resposta);
    if(resposta == 1) { //Caso o evento tenha acontecido, realiza as alterações
      pontos += 50;
    }
    printf("Pontos: %d\n", pontos);

    printf("Evento 2: O jogador coletou item especial? 1: Sim, 0: Nao.\n");
    scanf("%d", &resposta);
    if(resposta == 1) {
      pontos *= 2;
    }
    printf("Pontos: %d\n", pontos);

    printf("Evento 3: O jogador perdeu uma vida? 1: Sim, 0: Nao.\n");
    scanf("%d", &resposta);
    if(resposta == 1) {
      pontos -= 30;
    }
    printf("Pontos: %d\n", pontos);

    printf("Evento 4: O jogador tem bonus de tempo? 1: Sim, 0: Nao.\n");
    scanf("%d", &resposta);
    if(resposta == 1) {
      pontos += 15;
    }
    printf("Pontos: %d\n", pontos);

    printf("Evento 5: O jogador tem penalidade por dificuldade? 1: Sim, 0: Nao.\n");
    scanf("%d", &resposta);
    if(resposta == 1) {
      pontos /= 3;
    }
    printf("Pontos: %d\n", pontos);

    printf("Evento 6: O jogador tem bonus final? 1: Sim, 0: Nao.\n");
    scanf("%d", &resposta);
    if(resposta == 1) {
      pontos += 100;
    }
    printf("Pontos: %d\n", pontos);

    printf("\n=== RESULTADO FINAL ===\n"); //apresenta os resultados finais
    printf("Pontuacao inicial: %d\n", aux);
    printf("Pontuacao final: %d\n", pontos);
    vabs = abs(aux - pontos); //calcula valor absoluto da diferença entre pontuação inicial e final
    printf("Diferenca de pontuacao: |%d - %d| = %d\n", aux, pontos, vabs);

  return 0;
}