#include <stdio.h>
#include <ctype.h>

int main() {
    float peso, altura, imc;
    int idade, clas;
    char sexo;

    printf("\n=== CALCULO DE IMC ===\n");

    do { // Laço DO WHILE com leitura e validação do peso.
    printf("Qual o seu peso em quilogramas?\n");
    if(scanf("%f", &peso) != 1) { // Se não numérico, interrompe o programa.
        printf ("Peso invalido. Por favor, insira apenas valores numericos.");
        return 1;
    }
    } while (peso < 0.00f); // Continua perguntando até valor maior que 0.
    
    do { // Laço DO WHILE com leitura e validação de altura.
    printf("Qual a seu altura em metros?\n");
    if(scanf("%f", &altura) != 1) { // Se não numérico, interrompe o programa.
        printf ("Altura invalida. Por favor, insira apenas valores numericos.");
        return 1;
    } 
    } while (altura <= 0.00f); // Continua perguntando até valor maior que 0.

    do { // Laço DO WHILE com leitura e validação de idade.
    printf("Qual a seu idade em anos?\n");
    if(scanf("%d", &idade) != 1) { // Se não numérico, interrompe o programa.
        printf ("Idade invalida. Por favor, insira apenas valores numericos inteiros.");
        return 1;
    }
    } while (idade < 0); // Continua perguntando até valor maior que 0.

    do { // Laço DO WHILE com leitura e validação do sexo.
    printf("Qual o seu sexo? (F/M): \n"); 
    if(scanf(" %c", &sexo) != 1) { // Se não for caractere, interrompe o programa.
        printf ("Sexo invalido. Por favor, insira apenas caracteres validos.");
        return 1;
    }
    sexo = toupper((unsigned char)sexo); // Transforma carcatere em maiúsculo caso necessário.
    } while (sexo != 'F' && sexo != 'M'); // Segue perguntando até caractere válido.

    printf("\n=== RESULTADO DO IMC ===\n"); // Saída de resultados
    imc = peso / (altura * altura); // Calcula IMC
    printf("Seu IMC: %.2f\n", imc); 
    if(imc < 18.50f) { // IF com a classificação e descrição para cada IMC
        clas = 1;
        printf("Voce esta abaixo do peso: IMC < 18.5\n");
    } else if (imc < 25.00f) {
        clas = 2;
        printf("Voce esta com o peso normal: 18.5 <= IMC < 25.0\n");
    } else if (imc < 30.00f) {
        clas = 3;
        printf("Voce esta com sobrepeso: 25.0 <= IMC < 30.0\n");
    } else if (imc < 35.00f) {
        clas = 4;
        printf("Voce esta com obesidade grau I: 30.0 <= IMC < 35.0\n");
    } else if (imc < 40.00f) {
        clas = 5;
        printf("Voce esta com obesidade grau II: 35.0 <= IMC < 40.0\n");
    } else {
        clas = 6;
        printf("Voce esta com obesidade grau III: IMC >= 40.0\n");
    }

        if(sexo == 'M' && clas > 2) { // Sequência de IF's com recomendações personalizadas caso as entradas atendam as condições
        printf("RECOMENDACAO PERSONALIZADA: Exercicios de forca.\n");
        }
        if(sexo == 'F' && clas > 2) {
        printf("RECOMENDACAO PERSONALIZADA: Exercicios aerobicos.\n");   
        }
        if(idade >= 60 && clas == 1) {
            printf("RECOMENDACAO PERSONALIZADA: Consultar geriatra.\n");
        }
        if(idade <= 25 && clas > 3) {
            printf("RECOMENDACAO PERSONALIZADA: Procurar nutricionista.");
        } 

    return 0;
}