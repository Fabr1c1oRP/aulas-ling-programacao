#include <stdio.h>

int main() {
    double valor, taxa, saldo = 1000.00;
    int op, ok;

    do {
        ok = 1; // Inicia o laço de opções de transação, e parte com o ok (repetição) ativo.
        printf("\n=== MENU DE OPCOES ===\n");
        printf("1) Consultar saldo atual\n2) Realizar deposito\n3) Realizar saque\n4) Transferencia entre contas\n5) Sair do sistema\n");
        if(scanf("%d", &op) != 1) { // Lê opção digitada, e caso não seja retorno numérico, desativa repetição (ok = 0).
            ok = 0;
        }
        
        switch (op) { // Switch com todas as alterações de cada caso (1 ao 4 e default - para números que não sejam esses).
            case 1: 
                printf("Saldo atual: %.2lf\n", saldo); // Opção 1: Mostra saldo atual.
                break;
            case 2:
                printf("Quanto voce deseja depositar?\n"); // Opção 2: Primeiro pergunta quanto deseja depositar.
                if (scanf("%lf", &valor) != 1) { // Se não numérico, desativa repetição (ok = 0).
                    ok = 0;
                } else if (valor > 0.01) { // Se numérico, verifica se valor de depósito é maior que o mínimo permitido.
                    saldo += valor; // Soma valor de depósito.
                } else {
                    printf("ERRO! Valor deve atender o minimo para deposito: R$ 0.01\n"); // Se menor que o mínimo, mensagem de erro.
                }
                break;
            case 3:
                printf("Quanto voce deseja sacar?\n"); // Opção 3: Primeiro pergunta quanto deseja sacar.
                if(scanf("%lf", &valor) != 1) { // Se não numérico, desativa repetição (ok = 0).
                    ok = 0;
                } else if(valor <= 500.00 && valor <= saldo) { // Se numérico, verifica se valor é permitido. (<= 500 e <= saldo)
                    saldo -= valor; // Subtrai saque do saldo.
                } else {
                    printf("ERRO! O valor para saque nao pode exceder R$ 500.00 nem o saldo em conta.\n"); // Erro, caso número não permitido.
                }
                break;
            case 4:
                printf("Quanto voce deseja transferir?\n"); // Opção 4: Primeiro pergunta quanto deseja transferir.
                if(scanf("%lf", &valor) != 1) { // Se não numérico, desativa repetição (ok = 0).
                    ok = 0;
                } else { // Se numérico, começa contas:
                    taxa = valor * 0.01; // Calcula a taxa.
                    if(taxa < 2.00) { // Se a taxa for menor que R$ 2,00, considera mínimo de R$ 2,00 para a taxa.
                        taxa = 2.00;
                    }
                    printf("Taxa de transferencia: %.2lf\n", taxa); // Mostra a taxa calculada.
                    valor += taxa; // Soma taxa no valor a transferir.
                    if(valor <= saldo) { // Verifica se o valor a transferir é menor ou igual ao saldo.
                        saldo -= valor; // Subtrai transferencia do saldo.
                    } else {
                    printf("ERRO! O valor para transferencia nao pode exceder o saldo em conta.\n"); // Erro no caso de valor de transferência excedente ao saldo.
                }
                }
                break;
            default: // Caso seja digitado o número 5, ou qualquer valor não especificado, fecha a repetição (ok = 0)
                ok = 0;
                break;
        }
        if (op < 6 && op > 0) { // Se a a última opção escolhida e executada for válida, mostra operação e saldo atualizado.
        printf("Ultima operacao escolhida: %d\n", op);
        printf("Saldo apos ultima operacao: %.2lf\n", saldo);
        }
    } while(ok == 1); // Mantém a repetição do menu e suas execuções até que a repetição seja interrompida (ok = 0);
    printf("Voce saiu do sistema.\n"); // Aviso de que a repetição foi interrompida.
    return 0;
}