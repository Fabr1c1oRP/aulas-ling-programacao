#include <stdio.h>

int main() {
    float notas[3], media, freq;
    int i, ok;
    char conc[4] = {'A', 'B', 'C', 'D'};

    do { // Laço de repetição para validar entrada das notas.
        ok = 1; // Inicialmente entrada válida.
    for (i = 0; i < 3; i++) { // Laço FOR para inremento do índice das 3 notas.
        printf("\nDigite a nota %d:\n", i + 1);
        if (scanf("%f", &notas[i]) != 1 || notas[i] > 10.0f || notas[i] < 0.0f) { // Tratamento no caso de número inválido.
            printf("Entrada invalida.\n");
            ok = 0; 
            i = 3;
        }
    }
    } while (ok == 0); // Caso entrada permaneça válida, segue. Se não, volta ao laço de repetição.

    do { // Laço de repetição para validade da frequência (mesma lógica anterior).
        ok = 1;
        printf("\nDigite o percentual de frequencia:\n");
        if(scanf("%f", &freq) != 1 || freq > 100.0f || freq < 0.0f) {
            printf("Entrada invalida.\n");
            ok = 0;   
        }
    } while (ok == 0);

    media = (notas[0] + notas[1] + notas[2]) / 3.0f; // Calcula a média. Após isso, define o conceito da média.
    i = 0; // Índice 0 = "A" no CHAR conc.
    if (media < 5.0f) { 
        i = 3; // Índice 3 = "D" no CHAR conc.
    } else if (media < 7.0f) {
        i = 2; // Índice 2 = "C" no CHAR conc.
    } else if (media < 9.0f) {
        i = 1; // Índice 1 = "B" no CHAR conc.
    }

    printf("\n=== RESULTADOS APROXIMADOS E STATUS DA APROVACAO ===\n"); // Ínicio do cabeçalho com os resultados.
    printf("Media calculada: %.2f.\n", media);
    printf("Conceito obtido: %c.\n", conc[i]);
    if (i == 3 && freq < 75.0f) { // Sequência de IF's para resposta do status de aprovação.
        printf("Status da aprovacao: Reprovado por ambos (media < 5,0 E frequencia < 75%%);");
    } else if (freq < 75.0f) {
        printf("Status da aprovacao: Reprovado por frequencia (frequencia < 75%%);");
    } else if (media < 5.0f) {
        printf("Status da aprovacao: Reprovado por nota (media < 5,0).");
    } else {
        printf("Status da aprovacao: Aprovado (media >= 5,0 E frequencia >= 75%%).\n");
    }

    return 0; 
}