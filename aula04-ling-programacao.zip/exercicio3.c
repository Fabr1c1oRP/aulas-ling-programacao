#include <stdio.h>

// TODO: Implemente esta função usando apenas ponteiros
int encontrar_maior(int *array, int tamanho) {
// Dica: use um ponteiro para percorrer o array
// e outro para guardar o endereço do maior elemento
int *ponteiro = array; // Ponteiro aponta para o primeiro valor da matriz.
int *maior = array; // Assume o primeiro valor da matriz como maior.
    for(int i = 0; i < tamanho; i++) { // Laço for para comparar cada valor da matriz com o anterior.
        if(*(ponteiro + i) > *maior) {
            maior = ponteiro + i; // Se maior que o anterior, variável "maior" recebe esse endereço.
        }
    }
    return *maior; // Retorna reultado do maior valor encontrado.
}


int main() {

int numeros[] = {45, 23, 78, 12, 67, 34, 89, 56};

int tamanho = sizeof(numeros) / sizeof(numeros[0]);


int maior = encontrar_maior(numeros, tamanho);


printf("Array: ");

for(int i = 0; i < tamanho; i++) {

printf("%d ", numeros[i]);

}

printf("\nMaior elemento: %d\n", maior);


return 0;

}