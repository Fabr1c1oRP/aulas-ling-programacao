// Crie uma função que calcule área e perímetro de um retângulo usando ponteiros.
#include <stdio.h>

// Função com ponteiros para as variáveis a serem alteradas.
void calcular_retangulo(float largura, float altura, float *area, float *perimetro) {
    *area = largura * altura; // Cálculo área.
    *perimetro = 2 * largura + 2 * altura; // Cálculo perímetro.
}

int main() { // Função principal.
    float l = 5.0, h = 3.0;
    float area, perimetro;

    calcular_retangulo(l, h, &area, &perimetro); // Usa função criada.
    printf("Retangulo %.1f x %.1f\n", l, h); // Retorna os valores alterados.
    printf("Area: %.2f\n", area);
    printf("Perimetro: %.2f\n", perimetro);

    return 0;
}
