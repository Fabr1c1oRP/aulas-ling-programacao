#include <stdio.h>
#include <string.h>

// Função de contagem de caracteres passado no exemplo, para uso futuro.
int contar_caracteres(char *str) {
int contador = 0;
while(*str != '\0') {
contador++;
str++;
}
return contador;
}

// Função para inverter uma string usando ponteiros
void inverter_string(char *str) {
// TODO: Implemente usando dois ponteiros
// Um no início e outro no fim da string
char *pi = str; // Ponteiro início recebe primeiro caractere.
char *pf = str + (contar_caracteres(str) - 1); // Ponteiro fim recebe último caractere.
while (pi < pf) { // Enquanto o endereço de início não se encontrar com o endereço de fim.
    char temp = *pi; // Temp recebe primeiro caractere.
    *pi = *pf; // Primeiro caractere é trocado pelo último.
    *pf = temp; // Último caractere é trocado pelo primeiro, salvo em temp.
    pi++; // Incrementa para o próximo caractere à direita partir do início.
    pf--; // Decrementa para o próximo carcatere à esquera a partir do fim.
}
}


int main() {
char texto[] = "PONTEIROS";

printf("String original: %s\n", texto);
inverter_string(texto);
printf("String invertida: %s\n", texto);

return 0;
}