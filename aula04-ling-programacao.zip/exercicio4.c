#include <stdio.h>


// Função para calcular estatísticas de um array de notas

void calcular_estatisticas(float *notas, int quantidade,
float *media, float *maior, float *menor) {
// TODO: Implemente esta função
// Calcule média, maior e menor nota usando ponteiros

float *ponteiro = notas; // O ponteiro aponta para o primeiro valor da matriz.
*menor = *maior = *notas; // Assume o primeiro valor como menor e como maior ao mesmo tempo.
*media = 0;
    for(int i = 0; i < quantidade; i++) { // Laço for para comparar cada valor da matriz com o anterior.
            *media += *(ponteiro + i); // Incrementa media com a soma de cada valor.
        if(*(ponteiro + i) > *maior) {
            *maior = *(ponteiro + i); // Se maior que o anterior, variável "maior" recebe esse valor.
        } else if(*(ponteiro + i) < *menor) {
            *menor = *(ponteiro + i); // Se menor que o anterior, variável "menor" recebe esse valor.
        }
    }
    *media /= quantidade; // Incrementa a variável media com a divisao da soma realizada pela quantidade de notas (calcula a média e salv.)
}


int main() {
float notas[] = {8.5, 7.2, 9.1, 6.8, 8.9, 7.7, 9.5, 8.2};
int qtd_notas = sizeof(notas) / sizeof(notas[0]);
float media, maior, menor;

calcular_estatisticas(notas, qtd_notas, &media, &maior, &menor);

printf("=== RELATÓRIO DE NOTAS ===\n");
printf("Notas: ");
for(int i = 0; i < qtd_notas; i++) {
printf("%.1f ", notas[i]);
}
printf("\n");
printf("Média: %.2f\n", media);
printf("Maior nota: %.2f\n", maior);
printf("Menor nota: %.2f\n", menor);

return 0;
}