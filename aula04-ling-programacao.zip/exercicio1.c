#include <stdio.h>

int main () {
    float salario = 2500.50;
    float *ponteiro_salario; 

    // Faça o ponteiro apontar para salário.    
    ponteiro_salario = &salario;

    // Imprima o valor usando o ponteiro.
    printf("Valor apontado pelo ponteiro: %.2f\n", *ponteiro_salario);
    
    // Modifique o salario atraves do ponteiro
    *ponteiro_salario = 3000.00;
    
    // Imprima o novo valor.
    printf("Valor alterado pelo ponteiro: %.2f\n", salario);

    return 0;
}