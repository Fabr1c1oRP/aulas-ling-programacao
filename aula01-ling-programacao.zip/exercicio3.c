#include <stdio.h>

int main() {
    int op;
    float un1, un2; 

//cabe�alho com decis�o do usu�rio
printf ("\n=== CONVERSOR DE UNIDADES ===\n");
printf("O que deseja converter?\n");
printf("1: Celsius em Farenheit\n2: Metros em Quilometros\n3: Quilogramas em Libras\nOutro valor: Sair\n");
scanf("%d", &op);

//in�cio do la�o while do cabe�alho
while (op < 4 && op > 0) {
printf("Digite o valor da unidade a ser convertida:\n");
scanf("%f", &un1);

//realiza a convers�o
if (op == 1) {
    un2 = un1 * 1.8 + 32;
} else if (op == 2) {
        un2 = un1 / 1000;
    } else {
        un2 = un1 * 2.2046;
    }

//exibe resultado
printf("Resultado: %f\n", un2);

//fim do la�o while, retorna ao looping (cabe�alho � mostrado novamente)
printf ("\n=== CONVERSOR DE UNIDADES ===\n");
printf("O que deseja converter?\n");
printf("1: Celsius em Farenheit\n2: Metros em Quilometros\n3: Quilogramas em Libras\nOutro valor: Sair\n");
scanf("%d", &op);
}
return 0;
}
