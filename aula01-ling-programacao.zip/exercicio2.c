#include <stdio.h>

int main() {
	int n1, n2;
    float div;

printf("Digite o primeiro numero: \n");
scanf("%d", &n1);

printf("Digite o segundo numero: \n");
scanf("%d", &n2);

printf("\n=== RESULTADOS ===\n");   //calcula e mostra os resultados
printf("Adicao: %d + %d = %d\n", n1, n2, n1 + n2);
printf("Subtracao: %d - %d = %d\n", n1, n2, n1 - n2);
printf("Multiplicacao: %d * %d = %d\n", n1, n2, n1 * n2);
if (n2 != 0) {
	div = (float)n1/n2; // Converte as vari�veis para float e divide em seguida
    printf("Divisao: %d / %d = %.2f\n", n1, n2, div);
    printf("%d %% %d = %d\n", n1, n2, n1 % n2);
} else {
    printf("Divisao: Impossivel dividir por zero.\n");
}

return 0;
}
