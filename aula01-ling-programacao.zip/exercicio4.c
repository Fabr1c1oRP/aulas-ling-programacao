#include <stdio.h>

int main() {
    float notas[4], media = 0.0;
    int i = 0;

    printf("Digite as quatro notas para calcular a media e o resultado:\n");

    //incrementa soma das notas
    for (i = 0; i < 4; i++) {
    printf("Digite a nota %d: ", i + 1);
    scanf("%f", &notas[i]);
    media += notas[i];
    }

    //calcula a m�dia
    media /= i;

    //resultados
    printf("Media: %f\n", media);
    if(media >= 7) {
        printf ("Parabens, voce foi aprovado.\n");
    } else {
        printf ("Infelizmete, voce nao foi aprovado.\n");
    }

return 0;
}
